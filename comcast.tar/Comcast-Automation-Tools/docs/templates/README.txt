This folder contains specification templates.
  1. Functional (Requirements) 
  2. Design (Approach) 
  3. Test Checklist (Test Considerations, plan) 
  4. Release note
