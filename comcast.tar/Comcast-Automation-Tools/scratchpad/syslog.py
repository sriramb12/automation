from jnpr.junos import Device
from jnpr.junos.utils.config import Config
import sys
import xml.etree.ElementTree as ET

log="cli.log"
argc= len(sys.argv)
if argc > 1:
   log=(sys.argv[1])
print "Fetching logs from ", log

dev = Device(host='10.219.37.208', user='labroot', password='lab123', gather_facts=False)
dev.open()

cu = Config(dev)
#data = "event-options  { generate-event {" + evtStr + " } } "
#cmd = "event-options  { generate-event {" + evtStr + " } } "
#data=dev.rpc.get_syslog_events(stream=log, priority="level=93")
data=dev.rpc.get_syslog_events(stream=log, count="3")
print "dir=", dir(data)
print "type =", type(data)
print "data=", data
#for txt in data.itertext():
   #print txt,
