from jnpr.junos import Device
from jnpr.junos.utils.config import Config
import sys
import xml.etree.ElementTree as ET
from lxml import etree


log="cli.log"
argc= len(sys.argv)
if argc > 1:
   log=(sys.argv[1])
print "Fetching logs from ", log

dev = Device(host='10.219.37.208', user='labroot', password='lab123', gather_facts=False)
dev.open()

cu = Config(dev)
data=dev.rpc.get_route_information()
print "type =", type(data)
#print etree.parse(data)
for txt in data.itertext():
   print txt,

print "dir=", dir(data)
print "data=", data
