from jnpr.junos import Device
from lxml import etree

dev = Device(host='10.219.37.208', user='labroot', password='lab123', gather_facts=False)
dev.open()

cnf = dev.rpc.request_scripts_synchronize(all=True)
cnf = dev.rpc.request_scripts_synchronize(event=True)
