from jnpr.junos import Device
from jnpr.junos.utils.config import Config

dev = Device(host='10.219.37.208', user='labroot', password='lab123', gather_facts=False)
dev.open()

cu = Config(dev)
data = """interfaces { 
    xe-2/0/6 {
        description "pyez confed";
        unit 0 {
            family mpls;
        }      
    } 
}
protocols {
    mpls { 
        interface xe-2/0/6; 
    }
}
"""
print data
cu.load(data, format='text')
cu.pdiff()
if cu.commit_check():
   cu.commit()
else:
   print "failed"
   cu.rollback()
