echo hello >> /tmp/hello.log
cat /tmp/hello.log
