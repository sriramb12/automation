#!/bin/bash
logfile=messages
if [ "$#" -lt 2 ]; 
 then
  echo "Usage: ./$0 <pattern> <user> [logfile]"
  exit
fi
if [ "$#" -eq 3 ]; 
then
  logfile=$3
fi


echo -n Password: 
read -s password

echo
#echo $password
echo
echo "Running playbook as $2, searching log file:/var/log/$logfile"
echo
echo searching for $1
u=\"user\":\"labroot\",
#u=\"user\":\"$2\", 
p=\ \"password\":\"$password\",
l=\ \"logfile\":\"$logfile\"
v=\ {$p$u$l}
echo $v
export $v
ansible-playbook -i hosts getlogs.yml -e '$v'
#ansible-playbook -i hosts getlogs.yml -e '{ "password":"lab123","user":"labroot", "logfile":"messages"}'
if [ ! -f *txt ]
   then
	   echo no host was authenticated?
	   exit
fi
log=`date| sed 's/ /-/g'`.log
for i in *txt
 do
  grep -q $1 $i
  if [ $? -eq 0 ] ; then
	  host=`echo $i | sed 's/........$//'`
          count=`grep -c $1 $i`
	  echo $host has $count matches >> $log for $1
  fi
  rm -f $i
done

if [ ! -f $log ]
then
	echo no matches found for $1
        exit
fi
cat $log
echo
echo $log is created as a log
