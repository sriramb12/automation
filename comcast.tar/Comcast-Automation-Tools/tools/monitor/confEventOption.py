from jnpr.junos import Device
from jnpr.junos.utils.config import Config
import sys

freq=int(sys.argv[1])
print freq
dev = Device(host='10.219.37.208', user='labroot', password='lab123', gather_facts=False)
dev.open()

evtStr="TestEvent time-interval " + str(freq);
print evtStr
cu = Config(dev)
data = "event-options  { generate-event {" + evtStr + " } } "
cu.load(data, format='text')
cu.pdiff()
if cu.commit_check():
   dev.rpc.request_scripts_synchronize(event=True)
   cu.commit()
else:
   print "failed"
   cu.rollback()
