#!/usr/bin
#env python
# Demonstrates the use of the 'command' tag to execute arbritrary 'show' commands.
# This code was inspired by Ebben Aries's command-jnpr.py at
# https://github.com/leopoul/ncclient/blob/master/examples/juniper/command-jnpr.py
#
# usage: python ncclient_demo.py <show command> <xpath expression>
# python ncclient_demo.py 'show route 2600::/64' '//rt-entry/nh'
# 
# Jeff Loughridge
# August 2014
 
import sys
import getpass
 
from lxml import etree as etree
from ncclient import manager
from ncclient.xml_ import *
from ping import pingchk
from StringIO import StringIO
from devfpcpic import getFpcSlot
from devfpcpic import getVendorPort

import sys
import getpass
 
import xml4h
from ping import pingchk

user = "labroot" 
ip = "" 
password = "" 

#def getDeviceParams(sys):
 
def connect(host, port, user, password):
 
    try:
      conn = manager.connect(host=host,
            port=port,
            username=user,
            password=password,
            timeout=30,
            device_params = {'name':'junos'},
            hostkey_verify=False)
      return conn
 
    except Exception:
        print "connect(): failed"
        sys.exit(1)

def runcmd(cmd, conn, debugFile):
    print "in runcmd() ", cmd
    try:
        result = conn.command(command=cmd)
        #print "obtained command result.."
        #print (type(result), f)
        if debugFile:
          print >>debugFile, result.tostring
        xmlResult = etree.parse(StringIO(result.tostring))
        #print "obtained nodes.."
        return xmlResult
    except Exception:
        print "runcmd: Encountered critical error : bad credentials?"
        print e
        sys.exit(1)
 
    #print etree.tostring(tree)
    return result
    #return etree.XML(result.tostring)


print 'Argument List:', str(sys.argv)
argc= len(sys.argv)
if argc == 3:
     ip=sys.argv[1]
     user = sys.argv[2]
    # print 'usage:\n   python runcmd.py <device-ip> <user>" 
if argc == 2:
         ip=sys.argv[1]
         user = raw_input("Please enter the device user name: ")
         print "User: ", user

if argc == 1:
         ip = raw_input("Please enter the device IP: ")
         user = raw_input("Please enter the device user name: ")
         print "User: ", user

if pingchk(ip) == 0:
      password = getpass.getpass()
      #connect(ip, 830, user, password)
else:
      print ip, " is not reachable?"
      exit(0)


conn = connect(ip, 830, user, password)
cmd = 'show chassis hardware detail'
f = open('debug.xml', 'w+')
tree = runcmd(cmd, conn, f)
print tree
fpcpiclist = getFpcSlot(tree, False)
for node in fpcpiclist:
  cmd = "show chassis pic fpc-slot " + node[0] + " pic-slot " +  node[1]
  tree = runcmd(cmd, conn, f)
  if getVendorPort(tree, "FINIS", True):
    print cmd
#connect('10.219.37.208', 830, 'labroot', 'lab123', 'candidate')
