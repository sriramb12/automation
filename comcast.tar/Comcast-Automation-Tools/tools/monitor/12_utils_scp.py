from jnpr.junos import Device
from jnpr.junos.utils.scp import SCP

dev = Device(host='10.219.37.208', user='labroot', password='lab123')
dev.open()

with SCP(dev, progress=True) as scp:
     #scp.get('/var/tmp/nitin.log','info.txt')
     scp.put('test', '/tmp/test')
dev.close()
