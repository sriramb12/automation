#!/usr/bin/python
'''
This program finds a specific log (by pattern) is present in /var/log/messages for a given set of devices
assumes a file which contains a set of hosts (devices) one per line
Usage: ./checkLog <pattern>
  Ex: ./checkLog DEBUG
This is a multiline
comment.
    sample nodes.list ----
    10.219.37.4
    10.219.37.5
    10.219.37.208
    10.219.37.1
    10.219.37.233
'''
from threading import Thread
import getpass
from jnpr.junos import Device
from jnpr.junos.utils.config import Config
import sys

f = open('/dev/null', 'w')
sys.stderr = f

log="messages"
pattern=''
argc= len(sys.argv)
if argc != 3:
   print "Usage :  ", sys.argv[0], "<username> <pattern>"
   exit(0)

password = getpass.getpass()
username=(sys.argv[1])
pattern=(sys.argv[2])

foundNodes = ''
def checkLog(node, pattern):
  global foundNodes, password
  #print "checking ", node
  dev = Device(host=node, user=username, password=password, gather_facts=False, timeout=5)
  try:
    dev.open()
  except:
	  return 0
  dev.timeout=3
  try:
   data=dev.rpc.get_log(filename=log)
  except:
	  return 0
  count=0
  l=[]
  for txt in data.itertext():
     l=	   txt.split('\n')
  for i in l:
	#if i.find('da0s2a') > -1:
	if i.find(pattern) > -1:
		print node, "has the match for '", pattern, "'in ", log, "file"
		foundNodes += node
		foundNodes += ' '
	#        print foundNodes 
		dev.close()
		return 1

tlist=[]
try:
  with open('nodes.list', 'r') as nodelist:
	for line in nodelist:
	  node= line.strip()
	  t=Thread(target=checkLog, args=(node, pattern))
	  t.start()
#	  tlist.append(t)
	#print "num of theads:", len(tlist)
	#for t in tlist:
	#  t.start()
except:
	print "file: 'nodes.list' does not exist?"

if foundNodes:
	print "Nodes with matching log : "
	print foundNodes 
	print ""
