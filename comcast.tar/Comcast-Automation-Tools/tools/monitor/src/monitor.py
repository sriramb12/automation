from threading import Thread
import getpass
import sys
from jnpr.junos import Device
from jnpr.junos.utils.scp import SCP
from ping import pingchk

username = "" 
ip = "" 
password = "" 
cmdfile = "" 
freq = 0
def checkFreq(freq):
	  if not freq:
		  print "Invalid frequency specified:", freq
		  exit(0)
def getArgs():
 global username, ip, password, cmdfile, freq
 argc= len(sys.argv)
 if argc > 5:
    print "usage:\n   python ", sys.argv[0], "[device-ip] [user] [cmdfile] [frequency]"
    exit(0)
 if argc == 1:
         ip = raw_input("Please enter the device IP: ")

 if argc >= 2:
         ip=sys.argv[1]

 if pingchk(ip) != 0:
      print ip, " is not reachable?"
      exit(0)
 if argc == 2:
    username = raw_input("Please enter the device user name: ")
 else:
    username = sys.argv[2]
 password = getpass.getpass()
 if argc >= 4:
	 cmdfile = sys.argv[3]
 else:
	 cmdfile = raw_input("Please enter the command file name:")

 if argc == 5:
	 try:
	  freq = int(sys.argv[4])
         except Exception as err:
          print "invalid frequency"
	  exit(0)
 else:
	 freq = int(raw_input("Please enter the freq:"))
 checkFreq(freq)

getArgs()

def getMonitoringParams():
    freq = int(raw_input())
    getCommandFile() 	
    getCommandFile() 	
dev = Device(host=ip, user=username, passwd=password)

def configureEventOptions(freq):
 evtStr="testEvent time-interval " + str(freq);
 print evtStr
 cu = Config(dev)
 data = "event-options  { generate-event {" + evtStr + " } } "
 cu.load(data, format='text')
 cu.pdiff()
 if cu.commit_check():
   cu.commit()
 else:
   print "failed"
   cu.rollback()

try:
	    print "monitoring ", ip, "using commands from '", cmdfile, "' every ", freq, " minutes"
	    dev.open()
	    configureEventOptions(freq)
except Exception as err:
	    print err
	    sys.exit(1)


#print dev.facts
dev.close()
