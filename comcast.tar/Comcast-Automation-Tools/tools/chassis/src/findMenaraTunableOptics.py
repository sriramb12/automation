#!/usr/bin/python

#
# program to get optics information from a device
# 

# Then report these fields
# Router name,Router model,FPC#,PIC#,Port#,XFP Vendor,XFP Part No,Vendor SN,Wavelength,tunable(wl cntrl), cfged wl, tuned wl. tuned frq
# tested on oakland (10.8.51.13) regress/MaR...

#

from termcolor import colored
from sets import Set
from ncclient import manager
from pprint import pprint
from jnpr.junos import Device
from jnpr.junos.exception import *
from lxml import etree
from os import remove
import socket 
import time
import sys
import re
import argparse
import getpass

inFile='dev.txt'
outFile='out.csv'
debug = 0
scanAllFpcs = False
listMatchingPorts = False
host=''
username = ''
password = ''
vendorName = 'MENARA'
partNum = '6A'
parameter = "cntrl"
paramValue  = 'true'
hostPrefix  = 'ce-'
pfeDumpFile = '' 
########################################
def getFileName() :
   """This function generates a uniq filename based on current time
   In: -
   Out: updates the global: outFile with a file name
   """
   global outFile
   outFile = vendorName+"-"+partNum+"-"+(time.strftime("%d-%m-%Y")) +(time.strftime("-%H-%M-%S"))+'.csv'
   return outFile

########################################
def processArgs(args):
   global username, hostPrefix, debug, scanAllFpcs, listMatchingPorts, vendorName, partNum, parameter
   """This function processes the commandline arguments to set various globals
   In: args
   Out: updates various globals which control the parameters
   """
   if args.d :
     debug = args.d
     print "debug level", debug 
   if args.a:
     scanAllFpcs = False 
   if args.a:
         scanAllFpcs = True 
   if args.param:
         parameter = args.param  
   if args.pn:
         partNum = args.pn 
   if args.l:
         listMatchingPorts = True 
   if args.vendor:
       vendorName = args.vendor
   if args.input:
       inFile = args.input
   if args.output:
       outFile = args.output
   else:
       outFile = getFileName() 
       if debug:
         print outFile
   username = args.username

########################################
def getFpcType(desc):
   """
   This function determines if a given PIC slot is of type SFP or XFP
     IF MPCx -- SFP
     IF DPCx  
       1GE -- SFP
       10GE -- XFP
   """
   #print desc
   if 'MPC' in desc:
      return ' sfp '
   if '1GE' in desc:
      return ' sfp '
   return ' xfp '

########################################
def getFpcPic(device, fpcSet, scanXfps = True, debug=0):

   """
   This function takes a open device opject
     And the optional filter and returns 
     1. a list of list of fpc,pic in the chassis
     2. a set of <fpc,type> tuples 
   """

   results=[]

   #get the results of "show chassis hardware"
   chassis = device.rpc.get_chassis_inventory(normalize=True ) 
   #print(etree.tostring(chassis, pretty_print=True))
   for elem in chassis.iterfind('chassis/chassis-module/chassis-sub-module/[chassis-sub-sub-module]'):
      fpc = elem.getparent().find('name')
      pic = elem.find('name')
      desc = elem.getparent().find('description').text
      fpcType = getFpcType(desc)
      if(scanXfps and 'xfp' not in fpcType):
       if debug:
         print "Skipping ", fpc.text
         continue
      #process only the 'xfp' type FPCs
      if pic.text.startswith( "MIC" ):
         for pic in elem.iterfind('chassis-sub-sub-module/name'):
            results.append([re.search('\d+',fpc.text).group(0), re.search('\d+',pic.text).group(0)])
            #print "adding ", re.search('\d+',fpc.text).group(0)
      else:
         results.append([re.search('\d+',fpc.text).group(0),re.search('\d+',pic.text).group(0)])
         #print "adding ", re.search('\d+',fpc.text).group(0)
      fpcSet.add((fpc.text.split(' ')[1], fpcType))

   if debug > 1:
     print "The following FPCs will be scanned:"
     for elem in fpcSet:
       print elem[0], elem[1]

   return results

         
########################################

def getMatchingMenaraPorts(device, fpc, pic, vendorName, partNum, debug=0):

   """
   This function returns the xcvr infor for the given fpc/pic on the device
   A list of dictionarys are returned
   """

   result=[]

   # get the results of "show chassis pic fpc_slot X pic_slot Y"
   xcvr_detail = device.rpc.get_pic_detail( fpc_slot=fpc, pic_slot=pic, normalize=True )
   #print(etree.tostring(pic_detail, pretty_print=True))

   #print "slot =", pic_detail.xpath("//fpc-information/fpc/pic-detail/slot")[0].text
   #print "slot =", pic_detail.find("./fpc-information/fpc/pic-detail/slot")
   #print "pic-slot =", pic_detail.xpath("//fpc-information/fpc/pic-detail/pic-slot")[0].text
   #print "pic-type =", pic_detail.xpath("//fpc-information/fpc/pic-detail/pic-type")[0].text

   for xcvr in xcvr_detail.xpath("//fpc-information/fpc/pic-detail/port-information/port"):
      if vendorName in xcvr.find('sfp-vendor-name').text:
        port = xcvr.find('port-number').text 
        if debug:
          print vendorName, " optics Found in ", fpc, "/", pic, "/", port
        if  partNum in xcvr.find('sfp-vendor-pno').text:
           if debug:
             print "matching part number:", xcvr.find('sfp-vendor-pno').text
        try:
         wavelength = xcvr.find('wavelength').text
        except:
         wavelength = ""
        if debug:
         print "wl=", wavelength
           
        result.append({
                     'hostname': host,
                     'model': device.facts['model'],
                     'fpc': fpc,
                     'pic': pic,
                     'port': xcvr.find('port-number').text,
                     'sfp-vendor-name': xcvr.find('sfp-vendor-name').text,
                     'sfp-vendor-pno': xcvr.find('sfp-vendor-pno').text,
                     'wavelength': wavelength
                    })
        return result
                     
        if debug:
              print "part number doesn't match"
      
   return result


########################################

# Main program


#Parse command line arguments


parser = argparse.ArgumentParser(description="List the optics information from a device",
         epilog='''The fields returned by this program are:
hostname,model,fpc,pic,port,cable-type,fiber-mode,sfp-vendor-name,sfp-vendor-pno,wavelength,sfp-vendor-fw-version
''')
parser.add_argument("-d", type=int, nargs='?', default=0, help="debug level[terse=1, detailed >=2]")
parser.add_argument("-pn", nargs='?', default='6A', help="part number to be inspected(default 'parts matching '6A''")
parser.add_argument("-param", nargs='?', default='wl cntrl', help="parameter to be inspected(default 'wl cntrl'")
parser.add_argument("-l", nargs='?', default=0, help="list (-6A) matching parts")
parser.add_argument("-a", nargs='?', default=0, help="scan all FPCs (default only XFPs)")
parser.add_argument("-input", nargs='?', type=argparse.FileType('r'), default=inFile, help="list of ce(mxXXX) devices")
parser.add_argument("-output", nargs='?', type=argparse.FileType('w'), default=getFileName(), help="csv file")
parser.add_argument("-vendor", nargs='?', default='MENARA', help="vendor name")
parser.add_argument("--username",help="Username to use when logging into devices")
parser.add_argument("--port",type=int,default=22,help="Port to use when logging into devices")

#parser.add_argument("device",nargs='+',help="The device to log in to")

args = parser.parse_args()

def displayTerse(li):
   global host
   count = len(li)
   if count > 0:
     print host, has, count, vendorName,  "optics", parameter, "ports"
   else:
      print colored(host, 'red'), colored("has no matching ports", 'red')
      return
   print "  FPC  PIC   PORT"
   print " ------------------"
   for l in li:
        print "  ", l[1], "  ", l[2], "   ", l[3]

########################################
printHeader = 0
header= "Router name,Router model,FPC#,PIC#,Port#,XFP Vendor,XFP Part No,Vendor SN,Wavelength,tunable(wl cntrl), cfged wl, tuned wl, tuned frq"
def displayParams(dict, sn, wl, wlparam, cwl, twl, tfq):
   global printHeader, outFile
   if debug:
     print colored("writing to ", 'green'), colored(outFile, 'green')
   ofd = args.output
   if not ofd:
     print "Failed to open output file"
     exit(0)
   if not printHeader:
     print >> ofd, header 
     printHeader = 1

   print >> ofd, dict['hostname']+","+\
            dict['model']+","+\
            dict['fpc']+","+\
            dict['pic']+","+\
            dict['port']+","+\
            dict['sfp-vendor-name']+","+\
            dict['sfp-vendor-pno']+","+\
            sn + "," + wl + "," + wlparam + "," + cwl + "," + twl + "," + tfq 
########################################
def filterPortsByParam(conn, inventory, fpcSet, debug=1):
     global host
     reqFpcSet = Set()
     reqCmdPrfx = "request pfe execute target fpc"
     subCmdShow = ' command \"show '
     end = " info\""
     identEnd = " identifier\""
     for item in inventory:
     #print "  ", item['fpc'], "  ", item['pic'], "  ", item['port']
       reqFpcSet.add(item['fpc'])

     tunablePorts = []
     while fpcSet:
        elem = fpcSet.pop()
        #print elem
        if elem[0] in reqFpcSet:
          listCmd = reqCmdPrfx + (elem[0]) + subCmdShow  + elem[1]+ ' list\"'
          if debug:
            print listCmd
          result = conn.command(command=listCmd, format='text')
          list = result.tostring.split('Index')[1]
          for tuple in list.split('\n'): 
             #print tuple
             l = re.findall(r'\d+', tuple)
             if len(l) == 4:
                for item in inventory:
                   infoCmd = reqCmdPrfx
                   if item['fpc'] == l[1] and item['pic'] == l[2] and item['port'] == l[3]:
                     infoCmd += elem[0] + subCmdShow
                     infoCmd += elem[1] + l[0] 
                     idCmd = infoCmd + identEnd
                     infoCmd += end 
                     if debug:
                       print infoCmd
                     result = conn.command(command=infoCmd, format='text')
                     opticsDetails = result.tostring
		     if debug > 1:
			     print opticsDetails
#Terse O/p
                     if parameter in opticsDetails:
                       value = opticsDetails.split(parameter)[1].split('\n')[0]
                       confWl = opticsDetails.split('configured wavelength:')[1].split('\n')[0].replace('  ','').replace(' ','')
                       tunedWl = opticsDetails.split('tuned wavelength:')[1].split('\n')[0].replace('  ','').replace(' ','')
                       tunedFq = opticsDetails.split('tuned frequency:')[1].split('\n')[0].replace('  ','').replace(' ','')
                       result = conn.command(command=idCmd, format='text')
                       if debug > 1:
                         print result
                       sn = result.tostring.split('Vendor SN:')[1].split('\n')[0].replace('  ','').replace(' ','')
                       wavelength = result.tostring.split('Wavelength:')[1].split('\n')[0].replace(' ','')

                       if debug:
                          print "parameter:",parameter, sn, value, wavelength
                       
                       displayParams(item, sn, wavelength, re.sub('[^a-z]', '', value), confWl, tunedWl, tunedFq)
                       
                       if debug:
                         print value
                       if paramValue in value:
                          tunablePorts.append(l)
          return tunablePorts

ERR_INVALID_DEV_NAME=1
ERR_DEV_UNREACH=2
def run(hostName):
   global host, username, password, hostPrefix, debug, scanAllFpcs, listMatchingPorts, vendorName, partNum, parameter
   inventory=[]
   if debug:
     print "run()", hostName 
   host=hostName
   if not hostName.startswith(hostPrefix):
    if(debug):
      print "This program will process only devices with names starting with 'ce-', skipping", hostName
    return ERR_INVALID_DEV_NAME
   if debug:
    try:
      devIp = socket.gethostbyname(hostName)
      print 'The address of ', hostName, 'is', devIp
    except:
      print hostName, 'is unreachable'
      return ERR_DEV_UNREACH
   try:
      # connect to device
      dev=Device(host=hostName, port=args.port, user=args.username, password=password)
      dev.open()
      
   except Exception as err:
      print >> sys.stderr, "Cannot connect to ", device, ":", err
      return ERR_DEV_UNREACH


   fpcSet = Set()
   fpc_pic = getFpcPic(dev, fpcSet, scanAllFpcs, debug)

   for [fpc,pic] in fpc_pic:
      try:
         inventory = inventory + getMatchingMenaraPorts(dev,fpc,pic, vendorName, partNum, debug)
      except IndexError:
         pass

   dev.close()
   if debug:
     print inventory 
   if not inventory:
       print "no applicable optics found on ", host, "(", device, ")" 
       return 0
   conn = manager.connect(host=hostName, port=args.port,
            username =args.username, password=password,
            timeout=30,
            device_params = {'name':'junos'},
            hostkey_verify=False)
   filteredPorts = filterPortsByParam(conn, inventory, fpcSet, debug)
   displayTerse(filteredPorts)
   return 0

infd= open(inFile)
processArgs(args)
password = getpass.getpass()
count = 0
for device in infd:
   device = re.sub('[^a-z-.0-9]', '', device)
   if debug:
      print "processing:", device
   if not run(device):
    count+=1
if not count:
  print colored("no applicable device found, please check the dev.txt" , 'red')
  remove(outFile)
  if not debug:
   print colored(" alternatively, run with -d[level] for debug information", 'red')
else:
 print "processed ", count, " devices, output is written to ", outFile
